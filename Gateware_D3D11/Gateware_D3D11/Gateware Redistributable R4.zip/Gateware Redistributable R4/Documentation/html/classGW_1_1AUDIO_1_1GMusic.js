var classGW_1_1AUDIO_1_1GMusic =
[
    [ "~GMusic", "classGW_1_1AUDIO_1_1GMusic.html#a891eb13cdca2c2cdb6dbf0f72b8c3e69", null ],
    [ "DecrementCount", "classGW_1_1AUDIO_1_1GMusic.html#a1385376fffc42c40f5922b4722d10b5c", null ],
    [ "GetCount", "classGW_1_1AUDIO_1_1GMusic.html#ae41f54531b8325848215596fb2f821ac", null ],
    [ "GetStreamOutputChannels", "classGW_1_1AUDIO_1_1GMusic.html#a750dcb654e813c322d7617e1a5ebdf93", null ],
    [ "GetStreamSourceChannels", "classGW_1_1AUDIO_1_1GMusic.html#aef10f15b8487e18c2d65d1666ba64662", null ],
    [ "IncrementCount", "classGW_1_1AUDIO_1_1GMusic.html#a22d7a170b4d307e5398ebb92f950431f", null ],
    [ "isStreamPlaying", "classGW_1_1AUDIO_1_1GMusic.html#a0a0f4d5e0d11f7aec7ed9a1a6371df1a", null ],
    [ "PauseStream", "classGW_1_1AUDIO_1_1GMusic.html#a6a7a4efcf2d54bcf53429cedd7687e73", null ],
    [ "RequestInterface", "classGW_1_1AUDIO_1_1GMusic.html#a45b07d7915cfe61ab27338c42b78dcfb", null ],
    [ "ResumeStream", "classGW_1_1AUDIO_1_1GMusic.html#a56cc4db5fab860fdb948630b821bcdbd", null ],
    [ "SetChannelVolumes", "classGW_1_1AUDIO_1_1GMusic.html#a84e2bcb837e97f5653ab6c356122d705", null ],
    [ "SetVolume", "classGW_1_1AUDIO_1_1GMusic.html#a3a98aa8e77a9db8e9d1c735c4740391d", null ],
    [ "StopStream", "classGW_1_1AUDIO_1_1GMusic.html#a7d0ecd391a9723426dd3a24df7db1ad8", null ],
    [ "StreamStart", "classGW_1_1AUDIO_1_1GMusic.html#a3eec6db115638a770bf6ebfc7bc32f19", null ]
];