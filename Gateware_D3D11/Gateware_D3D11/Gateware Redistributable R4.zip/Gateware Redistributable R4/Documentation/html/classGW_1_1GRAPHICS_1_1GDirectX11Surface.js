var classGW_1_1GRAPHICS_1_1GDirectX11Surface =
[
    [ "GetAspectRatio", "classGW_1_1GRAPHICS_1_1GDirectX11Surface.html#a4ae8372993803025a14a8471835ed231", null ],
    [ "GetContext", "classGW_1_1GRAPHICS_1_1GDirectX11Surface.html#aceaa2e22cbdee6c651cf2045d9320041", null ],
    [ "GetDepthStencilView", "classGW_1_1GRAPHICS_1_1GDirectX11Surface.html#a44937f7b6e85b0b8df3ac6871c4b87a3", null ],
    [ "GetDevice", "classGW_1_1GRAPHICS_1_1GDirectX11Surface.html#a076c4f3a07f79f578185416be449ebd2", null ],
    [ "GetRenderTarget", "classGW_1_1GRAPHICS_1_1GDirectX11Surface.html#a953f4809860408b0e99928ac8b9b6a53", null ],
    [ "GetSwapchain", "classGW_1_1GRAPHICS_1_1GDirectX11Surface.html#a8388438c79a82a10f595e10b0bbaab2c", null ]
];