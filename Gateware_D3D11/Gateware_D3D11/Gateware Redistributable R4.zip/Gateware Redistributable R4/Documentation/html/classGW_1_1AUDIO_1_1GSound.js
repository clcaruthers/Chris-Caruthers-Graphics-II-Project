var classGW_1_1AUDIO_1_1GSound =
[
    [ "~GSound", "classGW_1_1AUDIO_1_1GSound.html#a62e7f97fed5a8d5f1d2fdf30f6f20413", null ],
    [ "DecrementCount", "classGW_1_1AUDIO_1_1GSound.html#afa9587ca984fc5ad2d5cdd47c3aebbcb", null ],
    [ "GetCount", "classGW_1_1AUDIO_1_1GSound.html#afbac022010da2fc1a917ece2803a36a4", null ],
    [ "GetSoundOutputChannels", "classGW_1_1AUDIO_1_1GSound.html#a9dcb3529b8819eedfd40e865a3bc611f", null ],
    [ "GetSoundSourceChannels", "classGW_1_1AUDIO_1_1GSound.html#acca8a7684851e32f4022006fd9eacf6c", null ],
    [ "IncrementCount", "classGW_1_1AUDIO_1_1GSound.html#a33149257f0958b4db57f5508492410ad", null ],
    [ "isSoundPlaying", "classGW_1_1AUDIO_1_1GSound.html#a904241837e93254806b2518f7da24ba9", null ],
    [ "Pause", "classGW_1_1AUDIO_1_1GSound.html#ababa7089fe9bf95d2763e4fde9c5a746", null ],
    [ "Play", "classGW_1_1AUDIO_1_1GSound.html#ae8bb1895e457825d81ce9ab4494d7c66", null ],
    [ "RequestInterface", "classGW_1_1AUDIO_1_1GSound.html#ac3c8f8dd06b71f86356a3e316fb3b4dc", null ],
    [ "Resume", "classGW_1_1AUDIO_1_1GSound.html#aae7e8c6cd723ba35d67e6c0ec2c4f794", null ],
    [ "SetChannelVolumes", "classGW_1_1AUDIO_1_1GSound.html#ac35f84bd0c936940bf641f9a937ca82a", null ],
    [ "SetVolume", "classGW_1_1AUDIO_1_1GSound.html#ad6d7995a245002485d8c2ec3a2051196", null ],
    [ "StopSound", "classGW_1_1AUDIO_1_1GSound.html#adb9e958fc6f853a37d0d84a7fcbe806c", null ]
];