var dir_79a34d4a005e6fa3ffc6f5421ac869d9 =
[
    [ "GDirectX11Surface.h", "GDirectX11Surface_8h_source.html", null ],
    [ "GGraphicsDefines.h", "GGraphicsDefines_8h_source.html", null ],
    [ "GOpenGLSurface.h", "GOpenGLSurface_8h_source.html", null ]
];