var structGW_1_1MATH_1_1GMATRIXD =
[
    [ "data", "structGW_1_1MATH_1_1GMATRIXD.html#a8751be0a0a7453662eda46a93889f0e4", null ],
    [ "row1", "structGW_1_1MATH_1_1GMATRIXD.html#a270fe0641cf9a788fcc9d10ec7b35747", null ],
    [ "row2", "structGW_1_1MATH_1_1GMATRIXD.html#a1bc368e1d72975a5225bd459f9c702e4", null ],
    [ "row3", "structGW_1_1MATH_1_1GMATRIXD.html#ad764bceafb36028a86a842360d92c48e", null ],
    [ "row4", "structGW_1_1MATH_1_1GMATRIXD.html#a56f3efe697bceb4e33833f95106e359b", null ]
];