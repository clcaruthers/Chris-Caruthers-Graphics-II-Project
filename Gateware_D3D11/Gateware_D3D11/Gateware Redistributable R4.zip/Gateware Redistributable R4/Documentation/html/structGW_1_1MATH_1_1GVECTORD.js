var structGW_1_1MATH_1_1GVECTORD =
[
    [ "data", "structGW_1_1MATH_1_1GVECTORD.html#a3f61f48fb22b0382f6558bc1fa7d8a60", null ],
    [ "w", "structGW_1_1MATH_1_1GVECTORD.html#a0820e1e99e3d83e4098616e9dd0fca7e", null ],
    [ "x", "structGW_1_1MATH_1_1GVECTORD.html#a7d3566f39f8c3149595edec8958c225c", null ],
    [ "y", "structGW_1_1MATH_1_1GVECTORD.html#a9929d4553067cc58a5477fdee56ac49b", null ],
    [ "z", "structGW_1_1MATH_1_1GVECTORD.html#a831403a04b3b15ecc9b265eb531bb8e4", null ]
];