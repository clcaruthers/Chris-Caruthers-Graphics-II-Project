var structGW_1_1MATH_1_1GQUATERNIOND =
[
    [ "data", "structGW_1_1MATH_1_1GQUATERNIOND.html#a80ffd8ebddc8cca59f90d0c9a11caf62", null ],
    [ "w", "structGW_1_1MATH_1_1GQUATERNIOND.html#aca1f0e5d5c2e3240b813b9588aa22a82", null ],
    [ "x", "structGW_1_1MATH_1_1GQUATERNIOND.html#a5780c909e288ae83c6af4c25fb61e568", null ],
    [ "y", "structGW_1_1MATH_1_1GQUATERNIOND.html#a2c06d425a33b3727161d287dfa9a6621", null ],
    [ "z", "structGW_1_1MATH_1_1GQUATERNIOND.html#abbafb17f1b95bf2268f1e3cda4009395", null ]
];