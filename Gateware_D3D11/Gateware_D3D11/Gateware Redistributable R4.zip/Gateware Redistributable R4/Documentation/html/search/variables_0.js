var searchData=
[
  ['data',['data',['../structGW_1_1SYSTEM_1_1GBUFFEREDINPUT__EVENT__DATA.html#abe62d14dd92dc136e8ab4f53ee26d794',1,'GW::SYSTEM::GBUFFEREDINPUT_EVENT_DATA']]]
];
