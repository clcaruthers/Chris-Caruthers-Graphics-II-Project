var classGW_1_1SYSTEM_1_1GLog =
[
    [ "EnableConsoleLogging", "classGW_1_1SYSTEM_1_1GLog.html#a1eb651aa3d5b6b8baac389be284a569d", null ],
    [ "EnableVerboseLogging", "classGW_1_1SYSTEM_1_1GLog.html#adea469091bba33b419f7e88a9c2c3049", null ],
    [ "Flush", "classGW_1_1SYSTEM_1_1GLog.html#a07147c15ecb17caa1c83974b3c54f7d4", null ],
    [ "Log", "classGW_1_1SYSTEM_1_1GLog.html#a9e21e702d012065fe799b4c49f7ac670", null ],
    [ "LogCatergorized", "classGW_1_1SYSTEM_1_1GLog.html#a5d10397fa6aeeebaf8430df6029ec3c5", null ]
];