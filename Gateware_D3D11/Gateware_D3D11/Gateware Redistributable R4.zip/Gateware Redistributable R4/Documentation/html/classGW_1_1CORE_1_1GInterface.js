var classGW_1_1CORE_1_1GInterface =
[
    [ "DecrementCount", "classGW_1_1CORE_1_1GInterface.html#a19a368c77ad0aa7f49b5a4f772f173ba", null ],
    [ "GetCount", "classGW_1_1CORE_1_1GInterface.html#aacf5834174a7024f8a3c361122ee9e76", null ],
    [ "IncrementCount", "classGW_1_1CORE_1_1GInterface.html#a2d710f20bb78e544e8309b5b75c21260", null ],
    [ "RequestInterface", "classGW_1_1CORE_1_1GInterface.html#ad6c8324970172784964f484686d4fdad", null ]
];