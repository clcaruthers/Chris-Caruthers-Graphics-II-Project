var structGW_1_1SYSTEM_1_1GBUFFEREDINPUT__EVENT__DATA =
[
    [ "data", "structGW_1_1SYSTEM_1_1GBUFFEREDINPUT__EVENT__DATA.html#abe62d14dd92dc136e8ab4f53ee26d794", null ],
    [ "keyMask", "structGW_1_1SYSTEM_1_1GBUFFEREDINPUT__EVENT__DATA.html#a7a818ba319e6693b89099938368a699e", null ],
    [ "screenX", "structGW_1_1SYSTEM_1_1GBUFFEREDINPUT__EVENT__DATA.html#a8c87335f76992eddba30abe7312b5b43", null ],
    [ "screenY", "structGW_1_1SYSTEM_1_1GBUFFEREDINPUT__EVENT__DATA.html#a066fa9b2dc654907d13590612238354d", null ],
    [ "x", "structGW_1_1SYSTEM_1_1GBUFFEREDINPUT__EVENT__DATA.html#a055e18b0d2aa3135ca8237bb06a0b4cb", null ],
    [ "y", "structGW_1_1SYSTEM_1_1GBUFFEREDINPUT__EVENT__DATA.html#a68facd2e2754c908ecf8b8ef4ce34e08", null ]
];