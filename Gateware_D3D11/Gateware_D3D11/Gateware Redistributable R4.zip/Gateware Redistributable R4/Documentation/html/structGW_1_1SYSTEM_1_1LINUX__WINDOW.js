var structGW_1_1SYSTEM_1_1LINUX__WINDOW =
[
    [ "display", "structGW_1_1SYSTEM_1_1LINUX__WINDOW.html#ae68b93065e8ebd9de010f42ccf688ac5", null ],
    [ "window", "structGW_1_1SYSTEM_1_1LINUX__WINDOW.html#a9d4ffe1d048716af5f2d1fe3595b6b99", null ]
];